<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br">

<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
	<script async src="https://www.googletagmanager.com/gtag/js?id=G-5TY98WLCRR"></script>
	<script>
		window.dataLayer = window.dataLayer || [];

		function gtag() {
			dataLayer.push(arguments);
		}
		gtag('js', new Date());

		gtag('config', 'G-5TY98WLCRR');

	</script>

	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" /> [meta]

	<title>[pagina]</title>

	<link href='favicon.png' rel='shortcut icon' type='image/x-icon' />

	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<meta name="format-detection" content="telephone=no" />
	<!-- <style><?php echo file_get_contents('template/pw-css/style.css');?></style> -->
	<link rel="stylesheet" type="text/css" href="[template]/pw-css/style.css" />
	<link rel="stylesheet" href="pw-font-awesome/css/all.css">
	<link href="https://fonts.googleapis.com/css?family=Exo+2&display=swap" rel="stylesheet">
	<link rel="stylesheet" href="pw-galeria-fancybox/jquery.fancybox.min.css">
	<link rel="stylesheet" href="pw-css/swiper.min.css">
	[css]
	<style>
		.logo-pw a {
			text-align: center;
			padding-top: 10px;
		}

	</style>
</head>

<body>



	<div class="linha-total">

		<div class="linha">
			<div class="item"><a href="https://api.whatsapp.com/send?1=pt_BR&phone=5511930739100&test=Ol%C3%A1%20estou%20interessado(a)%20nos%20servi%C3%A7os%20da%20ASB%20Consultoria%20" target="_blank"><i class="fab fa-whatsapp"></i> (11) 93073-9100</a></div>
			<!-- Item -->
			<div class="item"><i class="fas fa-envelope"></i> gov.compliance@asbtechnology.com.br</div>
			<!-- Item -->
			<div class="item"><i class="fas fa-map-marker-alt"></i> Avenida Regente Feijó, Nº 944 – Sala 1306B – Jardim Anália Franco | São Paulo – SP</div>
			<!-- Item -->
			<div class="item"><a href="https://www.instagram.com/asb_technology_/" target="_blank"><i class="fab fa-instagram"></i></a></div>
			<!-- Item -->
			<div class="item"><a href="https://www.facebook.com/asbtechnology" target="_blank"><i class="fab fa-facebook-f"></i></a></div>
			<!-- Item -->
			<div class="item"><a href="https://www.youtube.com/channel/UCQqwgLnekoknZ3MgycylCuA/" target="_blank"><i class="fab fa-youtube"></i></a></div>
			<!-- Item -->
		</div>
		<!-- linha -->

	</div>
	<!-- Linha Total -->

	<div class="topo-total">

		<div class="topo">

			<div class="logo"><a href="[url]/" title=""><img src="[template]/pw-images/logo.png" alt="" title="" /></a></div>
			<!-- Logo -->

			<div class="menu">

				<ul>
					<li><a href="[url]/" title="" data-icon="home">HOME</a></li>
					<li><a href="[url]/consultoria-especializada-em-projetos-de-ti" title="Consultoria Especializada em Projetos de TI" data-icon="Consultoria Especializada em Projetos de TI">EMPRESA</a></li>
					<li><a href="[url]/eventos-e-novidades-na-ti-asb-consultoria" title="Eventos e Novidades na TI ASB Technology" data-icon="Eventos e Novidades na TI ASB Technology">EVENTOS</a></li>
					<li><a href="[url]/servicos-especializados-e-projetos-em-ti-para-empresas" title="Serviços Especializados e Projetos em TI para Empresas" data-icon="Serviços Especializados e Projetos em TI para Empresas">PORTFÓLIO</a></li>
					<li><a href="[url]/contato-com-profissionais-de-ti-em-sao-paulo" title="Contato com Profissionais de TI em São Paulo" data-icon="Contato com Profissionais de TI em São Paulo">CONTATO</a></li>
					<li><a href="[url]/vagas-de-emprego-de-tecnologia-e-consultoria-na-asb" title="Vagas de Emprego de Tecnologia e Consultoria na ASB" data-icon="Vagas de Emprego de Tecnologia e Consultoria na ASB">TRABALHE CONOSCO</a></li>
				</ul>

			</div>
			<!-- Menu -->

		</div>
		<!-- Topo -->

	</div>
	<!-- Topo Total -->

	<a href="[url]/a-lei-lgpd">
		<div class="btn-lgpd">

			<div class="swiper-container-02">
				<div class="swiper-wrapper">

					<div class="swiper-slide">
						<div class="item">
							<p>Quer ficar em compliance com LGPD? </p>
						</div><!-- Item -->
					</div><!-- swiper-slide -->

					<div class="swiper-slide">
						<div class="item dois">
							<p>Como obter o Assessment LGPD?</p>
						</div><!-- Item -->
					</div><!-- swiper-slide -->

					<!-- <div class="swiper-slide">
						<div class="item">
							<p>Como se preparar para LGPD?</p>
						</div>
					</div>-->

					<!-- <div class="swiper-slide">
						<div class="item dois">
							<p>Como executar o Assessment LGPD?</p>
						</div>
					</div> -->

				</div>
			</div>
		</div>
	</a>

	<div class="global">

		[conteudo]

	</div>
	<!-- global -->

	<div class="rodape-total">

		<div class="rodape">

			<div class="item"><a href="https://api.whatsapp.com/send?1=pt_BR&phone=5511930739100&test=Ol%C3%A1%20estou%20interessado(a)%20nos%20servi%C3%A7os%20da%20ASB%20Consultoria%20" target="_blank"><i class="fab fa-whatsapp" aria-hidden="true"></i> (11) 93073-9100</a></div>
			<!-- Item -->
			<div class="item"><i class="fas fa-envelope"></i> contato@asbtechnology.com.br</div>
			<!-- Item -->
			<div class="item"><i class="fas fa-map-marker-alt"></i> Avenida Regente Feijó, Nº 944 – Sala 1306B – Jardim Anália Franco | São Paulo – SP, CEP: 03342-000</div>
			<!-- Item -->

		</div>
		<!-- Rodape -->
		<?php  if ($_SERVER['REQUEST_URI'] == "/") { ?>
		<div class="logo-pw">
			<a href="https://www.projetowebsite.com.br" title="" target="_blank"><img src="[template]/pw-images/logo-pw.png" alt="Criação de Site, Construção de Site, Desenvolvimento Web" title="Criação de Site, Construção de Site, Desenvolvimento Web" /></a>
		</div>
		<?php  } else { ?>
		<div class="logo-pw">
			<a href="https://www.siteprojetoweb.com.br" title="" target="_blank"><img src="[template]/pw-images/logo-pw.png" alt="Criação de Site, Construção de Site, Desenvolvimento Web" title="Criação de Site, Construção de Site, Desenvolvimento Web" /></a>
		</div>
<?php } ?> 
		<div class="faixa-rodape" style="display: none;">
			<?php echo file_get_contents('https://www.projetoweb.com.br/faixa/faixa-rodape-clientes.php ');?>
		</div>



	</div>
	<!-- Rodape Total -->

	<script>
		<?php echo file_get_contents('pw-js/jquery.js');?>

	</script>
	<script>
		<?php echo file_get_contents('pw-js/swiper.min.js');?>

	</script>
	<script>
		<?php echo file_get_contents('pw-js/scrollReveal.js');?>

	</script>
	<script>
		<?php echo file_get_contents('pw-js/javascript.js');?>

	</script>
	<script>
		<?php echo file_get_contents('pw-galeria-fancybox/jquery.fancybox.min.js');?>

	</script>
	<script src="[template]/pw-slider-engine/wowslider.js"></script>
	<script src="[template]/pw-slider-engine/script.js"></script>
	<script>
		(function($) {
			'use strict';
			window.sr = ScrollReveal();
			sr.reveal('.box-02 .item', {
				duration: 2000,
				origin: 'right',
				distance: '100px',
				viewFactor: 0.6,
				mobile: false
			}, 300);
			sr.reveal('.box-03 input, .box-03 textarea', {
				duration: 2000,
				origin: 'bottom',
				distance: '50px',
				viewFactor: 0.6,
				mobile: false
			}, 100);
			sr.reveal('.mapa', {
				duration: 2000,
				origin: 'bottom',
				distance: '0px',
				viewFactor: 0.6,
				mobile: false
			}, 300);
			sr.reveal('.texto-pages', {
				duration: 2000,
				origin: 'bottom',
				distance: '0px',
				viewFactor: 0.2,
				mobile: false
			}, 300);
			sr.reveal('.box1', {
				duration: 2000,
				origin: 'bottom',
				distance: '0px',
				viewFactor: 0.2,
				mobile: false
			}, 300);
		})();

		$(document).ready(function() {
			var hash = window.location.hash;
			if (hash == '#pw_site') {
				$('.faixa-rodape').css('display', 'block');
			}
		});

		function isMobile() {
			var userAgent = navigator.userAgent.toLowerCase();
			return (userAgent.search(/(android|avantgo|blackberry|bolt|boost|cricket|docomo|fone|hiptop|mini|mobi|palm|phone|pie|tablet|up\.browser|up\.link|webos|wos)/i) != -1);
		}

		if (isMobile()) {
			jQuery(document).ready(function() {
				var page = $(location).attr('href');
				if (page != 'http://oprojetoweb.com.br/provas/modelos-tela-cheia-programado/3/') {
					jQuery('html, body').animate({
						scrollTop: $("h1").offset().top
					}, 500);

				}
			});
		}

	</script>
</body>

</html>

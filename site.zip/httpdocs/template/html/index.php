<?php
$dadosPagina["titulo"]   = "ASB Technology em Compliance, Segurança da Informação e Auditoria";
$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Empresa Focada em Soluções Tecnológicas, Consultoria, Engenharia de Processos, Proteção de Dados Empresariais e Análise de Risco para o Território Nacional.\" />";
$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"ASB Technology em Compliance, Segurança da Informação e Auditoria\" />";
$dadosPagina["metas"][2] = "<link rel='stylesheet' type='text/css' href='template/pw-slider-engine/style.css' />";
$dadosPagina["css"] = "";
?>

<!-- Start WOWSlider.com BODY section -->
<!-- add to the <body> of your page -->
<div id="wowslider-container1">
    <div class="ws_images">
        <ul>
            <li><img src="[template]/pw-slider-data/images/1.jpg" alt="1" title="1" id="wows1_0" /></li>
            <li><img src="[template]/pw-slider-data/images/2.jpg" alt="2" title="2" id="wows1_1" /></li>
        </ul>
    </div>

    <div class="ws_shadow"></div>
</div>
<!-- End WOWSlider.com BODY section -->


<div class="box-01-total">

    <a class="entrar" href="[url]/consultoria-especializada-em-projetos-de-ti" title="Consultoria Especializada em Projetos de TI" data-icon="Consultoria Especializada em Projetos de TI">
        <div class="box-01">

            <div class="conteudo">
                <div class="titulo">BEM-VINDO AO<br />NOSSO SITE</div> <!-- Titulo -->
                <div class="linha">
                    <div class="barra"></div>
                </div> <!-- Linha -->
                <div class="texto">
                    A ASB Technology é uma empresa de TI localizada em São Paulo, somos especializados em serviços de consultoria nas mais diversas áreas de Tecnologia. Nosso objetivo é trazer agilidade nos processos, melhoria dos indicadores, mapeamento e controle de risco, desenvolvemos uma Governança eficiente com base nas melhores práticas de TI. </div> <!-- Texto -->
                <div class="entrar">Saber Mais</div> <!-- Entrar -->
            </div> <!-- Conteudo -->
            <div class="total-img-home">
                <div class="img">
                    <img src="[template]/pw-images/box-01-02.jpg" alt="" title="" />
                    <div class="info"><i class="far fa-thumbs-up"></i><br />"Atender Bem Para Atender Sempre"</div> <!-- Info -->
                </div> <!-- Img -->
                <p>ITIL EXPERT | COBIT | ISO 20000 | ISO 270001 | ISO 27002</p>
            </div>
        </div> <!-- Box 01 -->
    </a>

</div> <!-- conteudo index -->


<div class="box-02-total">

    <div class="box-02">

        <a class="conteudo" href="[url]/suporte-e-infraestrutura-de-ti" title="Suporte e Infraestrutura de TI" data-icon="Suporte e Infraestrutura de TI">
            <div class="item">

                <div class="img"><img src="[template]/pw-images/box-02-04.jpg" alt="" title="" /></div> <!-- Img -->
                <div class="titulo">SUPORTE INFRAESTRUTURA</div> <!-- Titulo -->
                <div class="conteudo">
                    Suporte especializado e dedicado aos clientes, através de sistemas e processos de Gerenciamento de Serviços de TI, usando como base os principais frameworks de mercado ITIL 4, ISO 20000.
                </div> <!-- Conteudo -->
                <div class="entrar">Saiba Mais</div> <!-- Entrar -->

            </div> <!-- Item -->
        </a>

        <a class="conteudo" href="[url]/seguranca-e-melhorias-do-ambiente-empresarial" title="Segurança e Melhorias do Ambiente Empresarial" data-icon="Segurança e Melhorias do Ambiente Empresarial">
            <div class="item">

                <div class="img"><img src="[template]/pw-images/box-02-01.jpg" alt="" title="" /></div> <!-- Img -->
                <div class="titulo">SEGURANÇA DA INFORMAÇÃO</div> <!-- Titulo -->
                <div class="conteudo">
                    Serviço completo de proteção e suporte na área de segurança provendo ferramentas e processos reconhecidos internacionalmente, atendendo demandas de incidentes, prevenção contra vulnerabilidades e ataques de cibercriminosos. Frameworks NIST, CIS, OWASP, ISO 27001/27002.
                </div> <!-- Conteudo -->
                <div class="entrar">Saiba Mais</div> <!-- Entrar -->

            </div> <!-- Item -->
        </a>
        <a class="conteudo" href="[url]/necessidades-de-processo-controle-e-gestao-de-acesso" title="Necessidades de Processo, Controle e Gestão de Acesso" data-icon="Necessidades de Processo, Controle e Gestão de Acesso">
            <div class="item">

                <div class="img"><img src="[template]/pw-images/box-02-02.jpg" alt="" title="" /></div> <!-- Img -->
                <div class="titulo">GOVERNANÇA DE TI</div> <!-- Titulo -->
                <div class="conteudo">
                    Nós temos um arsenal de controles e processos para impulsionar os recursos de tecnologia a um outro nível, promovendo uma série de padrões e organizações em nível operacional e gerencial afim de tornar os processos passíveis de auditoria, desta forma, permitindo a área de Tecnologia mensurar resultados e investir melhor os recursos. Frameworks COBIT, ITIL 4, CAPM.
                </div> <!-- Conteudo -->
                <div class="entrar">Saiba Mais</div> <!-- Entrar -->

            </div> <!-- Item -->
        </a>
        <a class="conteudo" href="[url]/analise-de-gestao-de-acesso-fornecedores-e-perfis-de-acesso" title="Análise de Gestão de Acesso, Fornecedores e Perfis de Acesso" data-icon="Análise de Gestão de Acesso, Fornecedores e Perfis de Acesso">
            <div class="item">

                <div class="img"><img src="[template]/pw-images/box-02-03.jpg" alt="" title="" /></div> <!-- Img -->
                <div class="titulo">COMPLIANCE</div> <!-- Titulo -->
                <div class="conteudo">
                    Serviço que estabelece controles e diretrizes organizacionais com o objetivo de garantir as metas da alta gestão, bem como dar suporte as demais áreas de controles internos, auditórias interna e externa, e demais conformidade que estão ligadas as estratégias de crescimento da organização.
                </div> <!-- Conteudo -->
                <div class="entrar">Saiba Mais</div> <!-- Entrar -->

            </div> <!-- Item -->
        </a>

    </div> <!-- BOx 02 -->

</div> <!-- Box 02 Total -->

<div class="box-03-total">

    <div class="box-03">

        <div class="linha">
            <div class="barra"></div>
        </div> <!-- Linha -->
        <div class="titulo">ENTRE EM <br />CONTATO</div> <!-- Titulo -->

        <form action="mail-contato.php" method="post">
            <div class="item">
                <input name="campo[Nome]" type="text" placeholder="Nome:" />
                <input name="campo[E-mail]" type="text" placeholder="E-mail:" />
                <input name="campo[Telefone]" type="text" placeholder="Telefone:" />
            </div> <!-- item -->
            <div class="item">
                <textarea name="campo[Mensagem]" placeholder="Mensagem:"></textarea>
            </div> <!-- item -->
            <input class="submit" type="submit" value="Enviar" />
        </form>

    </div> <!-- Box 03 -->

</div> <!-- Conteudo Pages -->

<div class="mapa">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.261536214713!2d-46.57184724920155!3d-23.55904858460884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5e9954a955bf%3A0x54468dc816840c93!2sAv.%20Reg.%20Feij%C3%B3%2C%20944%20-%20Vila%20Formosa%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2003342-000!5e0!3m2!1spt-BR!2sbr!4v1570805230640!5m2!1spt-BR!2sbr" width="1920" height="450" style="border:0" allowfullscreen></iframe>

</div> <!-- mapa -->
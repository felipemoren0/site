<?php
	$dadosPagina["titulo"]   = "Vagas de Emprego de Tecnologia e Consultoria na ASB";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Venha Trabalhar Conosco para Diversas Vagas de TI em São Paulo, Estágio na Área de Tecnologia, Consultor, Área de Suporte e Profissionais de Tecnologia.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Vagas de Emprego de Tecnologia e Consultoria na ASB\" />";
	$dadosPagina["css"] = "";
?>

<h1>Trabalhe Conosco</h1>

<div class="conteudo-pages">

	<div class="texto-pages">

		<p>Vem fazer parte da nossa equipe, envie seu curriculum através do endereço de e-mail abaixo:</p><br>

		<p><i class="fas fa-envelope-open-text"></i><a href="mailto:contato@asbtechnology.com.br"> contato@asbtechnology.com.br</a></p><br>

		<p>Seu curriculum será analisado por nossos especialistas, caso se enquadre em alguma de nossas vagas entraremos em contato. Muito obrigado!  <i class="far fa-smile-wink"></i></p>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

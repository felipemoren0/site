<?php
	$dadosPagina["titulo"]   = "Contato com Profissionais de TI em São Paulo";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Entre em Contato para Suporte Especializado, Orçamentos de Serviços de TI, Projetos de Tecnologia, Suporte de Governança e Compliance, e Suporte de Segurança.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Contato com Profissionais de TI em São Paulo\" />";
	$dadosPagina["css"] = "";
?>

<h1>Contato</h1>

<div class="conteudo-pages">
	<div class="texto-pages">

		<div class="formulario">

			<div class="dados">

				<p><i class="fas fa-envelope"></i> E-mail:<a href="mailto:contato@asbtechnology.com.br"> contato@asbtechnology.com.br</a></p> <br>

				<p><i class="fas fa-phone"></i> Comercial: (11) 93073-9100</p> <br>

				<p><i class="fas fa-map-marker-alt"></i> Avenida Regente Feijó, Nº 944 – Sala 1306B – Jardim Anália Franco | São Paulo – SP, CEP: 03342-000</p> <br>

				<p>Receba uma proposta sem compromisso através do nosso formulário: Clique na imagem -> <a href="https://docs.google.com/forms/d/19pkZfM7bQe_qC16tFB5iSnDAQFp5PXq8_exH-QADKhM/viewform?edit_requested=true" title="Formulário de Serviços" target="_blank"><i class="fas fa-laptop"></i></a></p> <br>

				<p><a href="https://www.instagram.com/asb_technology_/" target="_blank"><i class="fab fa-instagram"></i> Instagram </a></p> <br>

				<p><a href="https://www.facebook.com/asbtechnology" target="_blank"><i class="fab fa-facebook-f"></i> Facebook </a></p> <br>
				
				<p><a href="https://www.youtube.com/channel/UCQqwgLnekoknZ3MgycylCuA/" target="_blank"><i class="fab fa-youtube"></i> Youtube </a></p> <br>

				<p><a href="https://api.whatsapp.com/send?1=pt_BR&phone=5511964423068&test=Olá%20estou%20interessado(a)%20nos%20serviços%20da%20ASB%20Consultoria%20" target="_blank"><i class="fab fa-whatsapp"></i> Whatsapp </a></p> <br>

			</div>

			<div class="mapa.contato">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.261536214713!2d-46.57184724920155!3d-23.55904858460884!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5e9954a955bf%3A0x54468dc816840c93!2sAv.%20Reg.%20Feij%C3%B3%2C%20944%20-%20Vila%20Formosa%2C%20S%C3%A3o%20Paulo%20-%20SP%2C%2003342-000!5e0!3m2!1spt-BR!2sbr!4v1570805230640!5m2!1spt-BR!2sbr" width="100%" height="450" style="border:0" allowfullscreen></iframe>
			</div> <!-- mapa -->

		</div> <!-- Formulario -->

	</div><!-- Texto Pages -->
</div> <!-- conteudo pages -->

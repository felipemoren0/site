<?php
	$dadosPagina["titulo"]   = "Consultoria Especializada em Projetos de TI";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Empresa Especializada em Processos BPM/BPMN, Auditoria, Gestão de Risco, Compliance, Governança de TI, Indicadores de Solução e Segurança da Informação.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Consultoria Especializada em Projetos de TI\" />";
	$dadosPagina["css"] = "";
?>

<h1>A Empresa</h1>

<div class="conteudo-pages">

	<div class="texto-pages">

			<p>A <b>ASB Technology</b> é uma empresa de TI localizada em São Paulo, somos especializados em serviços de consultoria nas mais diversas áreas de Tecnologia. Nosso objetivo é trazer agilidade nos processos, melhoria dos indicadores, mapeamento e controle de risco, desenvolvemos uma Governança eficiente com base nas melhores práticas de TI, nossa equipe é especializada nos principais frameworks - ISO 2000, ISO 27001, ISO 27002, COBIT, atendemos as empresas de todos os portes e segmentos.</p>

			<br>

			<p>Sempre pensando prover soluções de qualidade na área de TI que vão de encontro ao negócio de nossos clientes, disponibilizamos diversos serviços com um ótimo custo benefício, priorizando sempre o crescimento de nossos parceiros e clientes.</p>

			<br>

			<p>Criada por profissionais que já estão no mercado de tecnologia a mais de 10 anos, a  <b>ASB Technology</b> tem um modelo de atendimento totalmente personalizado, levando consultores que entendam o dia a dia do seu negócio e propondo soluções que vão de encontro com as necessidades de seu negócio, aumentando assim a eficiência de sua empresa e consequentemente reduzindo custos, ponto de auditoria e retrabalho.</p>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

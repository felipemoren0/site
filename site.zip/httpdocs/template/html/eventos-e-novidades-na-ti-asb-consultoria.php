<?php
	$dadosPagina["titulo"]   = "Eventos e Novidades na TI ASB Technology";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Eventos de Inovação Tecnológica para Empresas, Segurança de Dados Empresariais, Projetos de TI, ITIL, COBIT, Normas ISO 20000, 270001, e 270002.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Eventos e Novidades na TI ASB Technology\" />";
	$dadosPagina["css"] = "";
?>

<h1>Eventos</h1>

<div class="conteudo-pages">

	<div class="texto-pages">

		<div class="galeria">

			<a href="[template]/pw-images/galeria/grande/01.jpg" title="Segurança da Informação" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/01.jpg" alt="Segurança da Informação" title="Segurança da Informação"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/02.jpg" title="Governança de TI" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/02.jpg" alt="Governança de TI" title="Governança de TI"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/03.jpg" title="Compliance" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/03.jpg" alt="Compliance" title="Compliance"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/04.jpg" title="Segurança da Informação" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/04.jpg" alt="Segurança da Informação" title="Segurança da Informação"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/05.jpg" title="Governança de TI" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/05.jpg" alt="Governança de TI" title="Governança de TI"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/06.jpg" title="Compliance" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/06.jpg" alt="Compliance" title="Compliance"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/01.jpg" title="Segurança da Informação" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/01.jpg" alt="Segurança da Informação" title="Segurança da Informação"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/02.jpg" title="Governança de TI" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/02.jpg" alt="Governança de TI" title="Governança de TI"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/03.jpg" title="Compliance" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/03.jpg" alt="Compliance" title="Compliance"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/04.jpg" title="Segurança da Informação" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/04.jpg" alt="Segurança da Informação" title="Segurança da Informação"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/05.jpg" title="Governança de TI" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/05.jpg" alt="Governança de TI" title="Governança de TI"/>
			</a>

			<a href="[template]/pw-images/galeria/grande/06.jpg" title="Compliance" target="_blank">
			<img src="[template]/pw-images/galeria/pequeno/06.jpg" alt="Compliance" title="Compliance"/>
			</a>

		</div>

		<h2>Estamos trabalhando para fazer os uploads de nossos eventos com uma experiência diferencial. <i class="far fa-laugh-wink"></i></h2>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

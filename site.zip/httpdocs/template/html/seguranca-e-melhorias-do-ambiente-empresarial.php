<?php
	$dadosPagina["titulo"]   = "Segurança e Melhorias do Ambiente Empresarial";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Identificação, Mitigação e Gestão das Vulnerabilidades no Ambiente Empresarial, CSIRT, Pentest, Hardening e Implementação de SOC / NOC para Empresas.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Segurança e Melhorias do Ambiente Empresarial\" />";
	$dadosPagina["css"] = "";
?>

<h1>Segurança da Informação</h1>

<div class="conteudo-pages">

	<div class="texto-pages">
		<h2><i class="far fa-lightbulb"></i> Departamento ou papel de Segurança da Informação</h2>
			<p>O papel de Segurança da Informação é responsável por garantir a disponibilidade, integridade e segurança dos dados corporativos.</p>
			<p>Para tal são utilizadas metodologias, frameworks e ferramentas de segurança que auxiliam na identificação e mitigação das falhas encontradas</p>

			<br>

			<div class="seguranca-total">
				<div class="seguranca">
					<div class="seguranca-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> CSIRT</h2>
					</div>
					<div class="seguranca-desc">
						<p>O termo é designado à profissionais que são responsáveis por administrar, identificar e mitigar as falhas de segurança, assim como proteger todos os dados corporativos.</p>

						<p>Cabe a eles desenvolver e coordenar todas as políticas, ferramentas e decisões que precisam ser tomadas no âmbito de segurança da informação. Normalmente, os csirts atuam no ambiente interno da empresa, devido à necessidade constante de estarem acompanhando as atividades operacionais, mudanças e melhorias.</p>
					</div>
				</div>

				<div class="seguranca">
					<div class="seguranca-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> Análise de Vulnerabilidade</h2>
					</div>
					<div class="seguranca-desc">
						<p>É o termo utilizado para definir o trabalho de identificação, mitigação e gestão das vulnerabilidades encontradas no ambiente.</p>

						<p>Todo o trabalho é documentado e entregue na forma de relatórios técnicos, gerenciais e executivos.</p>
					</div>
				</div>

				<div class="seguranca">
					<div class="seguranca-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> Pentest</h2>
					</div>
					<div class="seguranca-desc">
						<p>É o termo utilizado para definir o trabalho de intrusão (Ethical Hacking) dentro de um ambiente e / ou conjunto de aplicações.</p>

						<p>O pentest é realizado seguindo as melhores práticas da OWASP.</p>

						<p>Todo o trabalho é documentado e entregue na forma de relatórios técnicos, gerenciais e executivos.</p>
					</div>
				</div>

				<div class="seguranca">
					<div class="seguranca-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> Hardening</h2>
					</div>
					<div class="seguranca-desc">
						<p>É o trabalho de fortificação e proteção dos ativos, servidores e sistemas da empresa.</p>

						<p>Esse trabalho é realizado em conjunto com a Análise de Vulnerabilidade e o Pentest, proporcionando melhorias contínuas na segurança.</p>
					</div>
				</div>

			</div>

				<br>

					<h2><i class="fas fa-handshake"></i> Veja onde podemos apoiar</h2>
						<p>A ASB Technology faz um assessment em relação à segurança do ambiente, e adequa às necessidades do negócio proporcionando as melhorias necessárias. O Objetivo é identificar e mitigar todos os riscos e vulnerabilidades do ambiente. </p>

						<br>

						<p><b>Escopo Macro de Ações:</b></p>

							<ul>
								<li>Análise de Vulnerabilidades</li>
								<li>Pentest</li>
								<li>Workshop – Segurança da Informação</li>
								<li>Treinamento e programa de conscientização (LGPD)</li>
								<li>Hardening do Ambiente</li>
								<li>Implementação de SOC / NOC</li>
								<li>Gestão e Controle de Acessos</li>
							</ul>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

<?php
	$dadosPagina["titulo"]   = "Análise de Gestão de Acesso, Fornecedores e Perfis de Acesso";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Controles Internos, Análise de Risco para Empresas, Redução de Custos na TI, Privacidade e Proteção de Dados para Empresas, LGPD e GDPR.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Análise de Gestão de Acesso, Fornecedores e Perfis de Acesso\" />";
	$dadosPagina["css"] = "";
?>

<h1>Compliance</h1>

<div class="conteudo-pages">

	<div class="texto-pages">
		<h2><i class="far fa-lightbulb"></i> Departamento de Compliance</h2>
			<p>O papel ou departamento de Compliance é responsável por garantir o cumprimento de todas as leis, regras e regulamentos aplicáveis, com uma vasta gama de funções dentro da empresa (acompanhamento de atividades, prevenção de conflitos de interesses, etc). Atuando como a política interna de uma empresa, é improvável que o papel ou departamento de Compliance seja a unidade mais popular internamente. No entanto, é o departamento com importância na manutenção da integridade e reputação de uma empresa. Embora os custos com Compliance tenham disparado nos últimos anos, os custos por não conformidade - mesmo que acidental - podem ser muito maiores para uma instituição. O não cumprimento de leis e regulamentos pode levar a pesadas multas monetárias, sanções legais e regulamentares, além da perda de reputação.</p>

			<br>

			<div class="compliance-total">
				<div class="compliance">
					<div class="compliance-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> Compliance Officer</h2>
					</div>
					<div class="compliance-desc">
						<p>O termo é designado à profissionais que são responsáveis por administrar um programa de compliance. Cabe a eles desenvolver e coordenar todas as políticas, ferramentas e decisões que precisam ser tomadas no âmbito organizacional. Normalmente, os compliance officers atuam no ambiente interno da empresa, devido à necessidade constante de estarem acompanhando as atividades operacionais, mudanças e melhorias.</p>
					</div>
				</div>

				<div class="compliance">
					<div class="compliance-titulo">
						<h2><i class="fas fa-chevron-circle-right"></i> Necessidade do Negócio</h2>
					</div>
					<div class="compliance-desc">
						<p>É necessário que a empresa possua os requisitos e condições estabelecidos nas normas da Receita Federal do Brasil, que adote os procedimentos que demonstrem a qualidade de seus controles internos que visam o cumprimento das obrigações tributárias e permitam o monitoramento permanente pela fiscalização.</p>
					</div>
				</div>
			</div>

			<br>

			<h2><i class="fas fa-handshake"></i> Veja onde podemos apoiar</h2>
				<p>A ASB Technology faz um assessment nas áreas críticas de negócio efetuando um levantamento das informações estratégicas e os principais pontos de controles dos processos, compara com as necessidades de negócio e propõe as melhorias necessárias. O Objetivo é atender qualquer necessidade e equalizar com os requisitos de auditoria interna e externa através dos novos processos, ferramenta e pessoas treinadas pela ASB Technology durante o projeto para sustentação da operação dos serviços.</p>

				<br>

				<p><b>Macro escopo de ações:</b></p>

					<ul>
						<li>Assessment 360</li>
						<li>Desenho do processo As Is</li>
						<li>Workshop – discussões e definições To Be</li>
						<li>Treinamento e programa de conscientização</li>
						<li>Execução do controle</li>
						<li>Analise cíclica de maturidade</li>
					</ul>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

<?php
$dadosPagina["titulo"]   = "A Lei Geral de Proteção de Dados";
$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Capacitação ITIL, Segurança da Informação, LGPD, Assessment LGPD, Assessment Auditoria, Mapeamento LGPD, Lei de Proteção de Dados Pessoais.\" />";
$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"A Lei Geral de Proteção de Dados\" />";
$dadosPagina["css"] = "";
?>


<h1>LGPD</h1>

<div class="conteudo-pages">

	<div class="box1 servicos">
		<h2>Em Agosto de 2018, foi sancionado a Lei nº 13.708/2018 - LGPD (Lei Geral de Proteção De Dados), com previsão para entrada em vigor em Agosto de 2020, com as sanções jurídicas prorrogadas para Agosto de 2021.</h2>
	</div>

	<div class="box1">
		<p>As Leis sobre a privacidade estão a mudar no Brasil e a <b>ASB TECHNOLOGY</b>obtém as especializações necessárias para ajudar a sua empresa nos setores de Segurança da Informação, Governança de Dados e Processos de TI, com o objetivo de orientar e planejar as atividades impactadas nos requerimentos da Lei LGPD (Lei Geral de Proteção de Dados).</p>

		<p>Nosso time líder é composto por especialistas em: <br><br>

			<i class="fas fa-caret-right"></i> Segurança da Informação<br><br>
			<i class="fas fa-caret-right"></i> Governança de Dados<br><br>
			<i class="fas fa-caret-right"></i> Compliance e Processos de TI<br><br>
			<i class="fas fa-caret-right"></i> Auditorias de TI.
		</p>
	</div>

	<div class="box1 servicos">
		<h2>Objetivos da Lei LGPD</h2>
	</div>

	<div class="box1">
		<p>A LGPD cria uma nova estrutura legal para o uso de dados pessoais no Brasil, tanto online quanto off-line, nos setores público e privado. É importante observar que o país já possui mais de 40 normas legais no nível federal que lidam direta e indiretamente com a proteção da privacidade e dos dados pessoais em um sistema setorial. No entanto, a LGPD está substituindo e / ou complementando esse quadro regulatório setorial, que às vezes era conflitivo, obscuro, sem segurança jurídica e tornava o país menos competitivo no contexto de uma sociedade cada vez mais orientada a dados.</p>

		<p>Hoje, mais de 126 países no mundo possuem Leis para a proteção de dados pessoais visando à regulamentação do tratamento de dados das empresas, evitando-se o mau uso destes como também a responsabilização das empresas por isso, bem como os incidentes e acidentes com dados pessoais, e tem como objetivo:<br><br>

			<i class="fas fa-caret-right"></i> Proteção à privacidade;<br><br>
			<i class="fas fa-caret-right"></i> Liberdade de expressão, informação, comunicação e opinião;<br><br>
			<i class="fas fa-caret-right"></i> Inviolabilidade da intimidade, honra e da imagem;<br><br>
			<i class="fas fa-caret-right"></i> Desenvolvimento econômico, tecnológico e inovação;<br><br>
			<i class="fas fa-caret-right"></i> Livre iniciativa, livre concorrência e a defesa do consumidor;<br><br>
			<i class="fas fa-caret-right"></i> Direitos humanos, livre desenvolvimento da personalidade, dignidade e exercício da cidadania.
		</p>

		<p>
			Este tema é o resultado de uma ampla discussão, visa não apenas garantir os direitos individuais, mas também promover o desenvolvimento econômico, tecnológico e a inovação por meio de regras claras, transparentes e abrangentes para o uso adequado de dados pessoais. Possui aplicação transversal e multissetorial, tanto no setor público quanto no privado, online e off-line e lida com o conceito de dados pessoais listando as bases legais que autorizam seu uso - e o consentimento é apenas um deles - destacando a possibilidade de processar dados pessoais com base nos interesses legítimos do controlador de dados, além dos princípios gerais de proteção de dados; direitos básicos do titular dos dados - como direito de acesso, exclusão de dados e explicação; e as obrigações e limites que devem ser aplicados a qualquer entidade que processe dados pessoais.
		</p>

	</div>

	<div class="box1 servicos">
		<h2>Definições da Nova Lei</h2>
	</div>

	<div class="box1">
		<div class="box2  lgpd">
			<div class="box2-desc">
				<h2>A LGPD SE APLICA</h2>
			</div>
		</div>

		<p>
			<i class="fas fa-caret-right"></i> Aos dados pessoais de indivíduos localizados no Brasil;<br><br>
			<i class="fas fa-caret-right"></i> Quando o tratamento se dá no Brasil;<br><br>
			<i class="fas fa-caret-right"></i> Quando houver oferta de bens e serviços para indivíduos no Brasil.
		</p>

		<div class="box2  lgpd">
			<div class="box2-desc">
				<h2>A LGPD NÃO SE APLICA</h2>
			</div>
		</div>

		<p>
			<i class="fas fa-caret-right"></i> Para dados provenientes e destinados a outros países, que apenas transitem pelo território nacional;<br><br>
			<i class="fas fa-caret-right"></i> Uso pessoal;<br><br>
			<i class="fas fa-caret-right"></i> Uso não comercial;<br><br>
			<i class="fas fa-caret-right"></i> Fins jornalísticos;<br><br>
			<i class="fas fa-caret-right"></i> Acadêmicos;<br><br>
			<i class="fas fa-caret-right"></i> Segurança pública.
		</p>

	</div>

	<div class="box1 servicos">
		<h2>Aplicação Extraterritorial</h2>
	</div>

	<div class="box1">
		<p>
			De maneira semelhante ao Regulamento Geral de Proteção de Dados da União Europeia, o dever de conformidade excederá os limites geográficos do Brasil. Qualquer empresa estrangeira que tenha pelo menos uma filial no Brasil ou ofereça serviços ao mercado brasileiro e colete e trate dados pessoais de titulares de dados localizados no país, independentemente da nacionalidade, estará sujeita à nova Lei.
		</p>

	</div>

	<div class="box1 servicos">
		<h2>Conceito de Dados Pessoais</h2>
	</div>

	<div class="box1">
		<p>
			Dados Pessoais (art. 5º, I) são os dados que permitem identificar uma pessoa ou torná-la identificável.
		</p>

		<p>São exemplos de dados pessoais:<br><br>

			<i class="fas fa-caret-right"></i> Nome<br><br>
			<i class="fas fa-caret-right"></i> Endereço<br><br>
			<i class="fas fa-caret-right"></i> Números Únicos Identificáveis (RG, CPF, CNH)<br><br>
			<i class="fas fa-caret-right"></i> Geolocalização<br><br>
			<i class="fas fa-caret-right"></i> Hábitos de Consumo<br><br>
			<i class="fas fa-caret-right"></i> Exames Médicos<br><br>
			<i class="fas fa-caret-right"></i> Dados referentes à saúde<br><br>
			<i class="fas fa-caret-right"></i> Biometria<br><br>
			<i class="fas fa-caret-right"></i> Perfil Cultural
		</p>

		<p>A LGPD fornece um conceito amplo do que devem ser considerados Dados Pessoais relacionados a uma pessoa física identificada ou identificável, ou seja, quaisquer dados, isolados ou agregados a outros, que possam permitir a identificação de uma pessoa singular ou sujeitá-la a um determinado comportamento. Praticamente todos os dados podem eventualmente ser considerados pessoais, portanto, sujeitos à Lei.</p>

		<p>Uma subcategoria de dados pessoais é denominada de: <br><br>

			<b>DADOS PESSOAIS SENSÍVEIS</b> (art. 5º, II), que por sua relevância e importância demandam mais proteção do um dado pessoal comum. São estes: dado pessoal sobre origem racial ou étnica, convicção religiosa, opinião política, filiação a sindicato ou a organização de caráter religioso, filosófico ou político, dado referente à saúde ou à vida sexual, dado genético ou biométrico, quando vinculado a uma pessoa natural. <br><br>

			Outro conceito é <b>DADO ANONIMIZADO</b>: Dado relativo ao titular que não possa ser identificado, considerando a utilização de meios técnicos razoáveis e disponíveis na ocasião de seu tratamento. Assim, a anonimização é entendida como a utilização de meios técnicos razoáveis e disponíveis no momento do tratamento, por meio dos quais um dado perde a possibilidade de associação, direta ou indireta, a um indivíduo. <br><br>
			O titular dos dados pessoais é toda pessoa natural a quem se referem os dados pessoais que são objeto de tratamento.
		</p>

	</div>


	<div class="box1 servicos">
		<h2>Definição de Tratamento de Dados Pessoais</h2>
	</div>

	<div class="box1">
		<p>
			Trata-se de toda operação realizada com dados pessoais, como as que se referem a coleta, produção, recepção, classificação, utilização, acesso, reprodução, transmissão, distribuição, processamento, arquivamento, armazenamento, eliminação, avaliação ou controle da informação, modificação, comunicação, transferência, difusão ou extração;
		</p>

		<div class="box2  lgpd">
			<div class="box2-desc">
				<h2>DADOS PÚBLICOS</h2>
			</div>
		</div>

		<p>
			Houve muita discussão sobre os limites do uso de dados pessoais acessíveis ao público, como os contidos em bancos de dados gerenciados por órgãos públicos, publicações oficiais e registros notariais, ou aqueles expressamente tornados públicos por seus titulares de dados, como perfis públicos nas redes sociais. A LGPD lida com essas situações, tratando-as de diferentes maneiras e impondo certas limitações, como o uso aos propósitos que levaram à divulgação dos dados pessoais acessíveis ao público. Isso não significa que os dados públicos não possam mais ser usados para outros fins, apenas que os modelos de negócios que dependem desse tipo de dados terão que se adaptar.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Fundamentos Legais para o Processamento de Dados - Consentimento e Interesses Legítimos</h2>
	</div>

	<div class="box1">
		<p> Para tratar dados pessoais, que incluem a prática de coletá-los, é sempre necessário ter uma base legal. A LGPD lista 10 hipóteses que autorizam o uso de dados pessoais, e o consentimento inequívoco é apenas um deles. Deve-se observar que a base jurídica conhecida como "interesse legítimo", que não existia na estrutura legal brasileira anterior de proteção de dados, permitiria o uso dos dados para outros fins que não aqueles originalmente autorizados por seus titulares de dados ou aqueles que lideraram à sua divulgação. Por meio de um teste de proporcionalidade que leva em consideração os interesses dos controladores e os direitos do titular dos dados, essa hipótese permitiria novos usos para os dados, tornando-os essenciais em tempos de big data, inteligência artificial, aprendizado de máquina e modelos de negócios inovadores com base no uso de dados pessoais.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Princípios Gerais de Proteção de Dados</h2>
	</div>

	<div class="box1">
		<p>A LGPD lista 10 princípios que devem ser levados em consideração no processamento de dados pessoais, como limitação de objetivos, necessidade, transparência, segurança, não discriminação e o novo princípio de responsabilidade, que torna obrigatório que o controlador e o processador de dados demonstrem total e transparentemente a adoção de medidas efetivas capazes de provar o cumprimento das regras de proteção de dados pessoais. Isso pode ser feito através de avaliações de proteção de dados, metodologias também previstas em Lei.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Direitos Básicos dos Titulares de Dados</h2>
	</div>

	<div class="box1">
		<p>Os titulares de dados terão seus direitos básicos expandidos e devem ser garantidos de maneira acessível e eficaz. Entre os direitos listados, é importante destacar o direito de acesso a dados, retificação, cancelamento ou exclusão, oposição ao tratamento, direito a informações e explicações sobre o uso de dados. A grande novidade é o direito à portabilidade de dados, que permite ao titular dos dados não apenas solicitar uma cópia completa de seus dados, mas também fornecê-los em um formato interoperável, que visa facilitar sua transferência para outros serviços, mesmo para concorrentes. Devido à sua natureza, esse novo direito tem sido visto como um forte elemento de concorrência entre diferentes empresas que oferecem serviços semelhantes com base no uso de dados pessoais.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Responsabilidade</h2>
	</div>

	<div class="box1">
		<p>Os diferentes agentes envolvidos no processamento de dados - o controlador e o processador - podem ser solidariamente responsáveis por incidentes de segurança da informação e / ou uso inadequado e não autorizado dos dados ou por não conformidade com a Lei. No entanto, a responsabilidade do processador, que pratica o processamento de dados em nome do controlador, pode ser limitada às suas obrigações contratuais e de segurança da informação se não violar as regras impostas pela LGPD. Portanto, é importante definir se uma empresa deve ser vista como um controlador ou processador, ou ambos, para definir os limites de sua responsabilidade.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Notificação Obrigatória de Violação de Dados</h2>
	</div>

	<div class="box1">
		<p>As notificações de violação de dados à Autoridade de Proteção de Dados se tornam obrigatórias e devem ser executadas dentro de um prazo razoável que pode, com base na gravidade do caso, determinar a notificação para todos os envolvidos e a ampla publicidade de o incidente.
		</p>
	</div>



	<div class="box1 servicos">
		<h2>Transferências Internacionais de Dados</h2>
	</div>

	<div class="box1">
		<p>A LGPD traz uma série de instrumentos legais que permitem a transferência internacional de dados pessoais, mesmo para países que não são considerados como tendo um nível adequado de proteção. Será possível transferir dados pessoais internacionalmente com base no consentimento específico e expresso do titular dos dados, que deve ser anterior e separado dos outros propósitos e requisições de consentimento. Também será possível realizar a transferência se houver garantia, pelo controlador, por meio de instrumentos contratuais, como regras corporativas vinculativas e cláusulas padrão, de que ele cumprirá os princípios, direitos dos titulares de dados e o regime de proteção de dados previsto em Lei. Semelhante ao RGPD, a Lei permite a transferência por meio da adoção de selos, certificados e códigos de conduta emitidos e autorizados pela Autoridade de Proteção de Dados.
		</p>
	</div>



	<div class="box1 servicos">
		<h2>Responsável pela Proteção de Dados</h2>
	</div>

	<div class="box1">
		<p>
			A Lei também prevê a criação do cargo de encarregado ou DPO – Data Protection Officer, o qual poderá ser pessoa física ou jurídica, cujas atividades serão aceitar reclamações, prestar esclarecimentos aos titulares e às autoridades, orientar as respectivas empresas e executar as diretrizes do diretor. O DPO terá sua identidade disponibilizada aos titulares e autoridades e seu contato deverá ser disponibilizado de forma simples e de fácil acesso. </p>

		<p>
			O DPO é a pessoa singular, nomeada pelo responsável pelo tratamento, que atua como um canal de comunicação entre o responsável pelo tratamento, os titulares dos dados e a Autoridade de Proteção de Dados. Além disso, o DPO deve ser responsável dentro da instituição pelo cumprimento da empresa com as regras previstas em Lei e orientar os funcionários e contratados da entidade em relação às práticas a serem adotadas em relação à proteção de dados pessoais. Uma leitura inicial da LGPD permite concluir que qualquer entidade que trata dados pessoais deve indicar um DPO, mas a autoridade de proteção de dados pode estabelecer normas complementares sobre a definição e as atribuições da pessoa responsável, incluindo hipóteses nas quais as empresas não precisa nomear um DPO.

		</p>
	</div>



	<div class="box1 servicos">
		<h2>Sanções</h2>
	</div>

	<div class="box1">
		<p>
			Sanções administrativas podem ser aplicadas por autoridade em caso de violação da LGPD.
		</p>

		<p>
			Entre as sanções, existem avisos e multas, que podem variar de 2% do faturamento da empresa, grupo ou conglomerado no Brasil em seu último ano fiscal, limitado no total a 50.000.000,00 (cinquenta milhões de reais) por infração. Existe também a possibilidade de multas diárias para obrigar a entidade a cessar as violações.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Período de Adaptação</h2>
	</div>

	<div class="box1">
		<p>
			A Autoridade Nacional, quando criada, pode estabelecer regras sobre a adaptação progressiva dos bancos de dados criados até a data de entrada em vigor da Lei, considerando a complexidade das operações de processamento e a natureza dos dados.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Vetos</h2>
	</div>

	<div class="box1">
		<p>
			A Autoridade Nacional de Proteção de Dados, um dos pontos mais relevantes estabelecidos pela Lei, foi vetada devido a aspectos legais relacionados a qual ramo do governo deveria ter desencadeado a nova Lei. No entanto, o Presidente já mencionou que a autoridade será criada através de uma Lei separada.
		</p>
		<p>
			O Presidente também vetou três artigos do projeto, que tratavam da proteção de dados pessoais de acesso a solicitações de informações, transferência de dados pessoais entre autoridades públicas e entidades privadas - essa transferência não será proibida, mas será baseada em outras bases jurídica e transparência no uso de dados compartilhados entre entidades públicas.
		</p>
		<p>
			Também foram vetados os artigos VII, VIII e IX do artigo 52, que previam sanções pela suspensão e proibição, total ou parcial, das atividades de processamento e armazenamento de dados pessoais em casos de violação da legislação. Dessa forma, apenas as penalidades de advertência, multa, bloqueio ou eliminação de dados e divulgação da infração são fornecidas.
		</p>
	</div>


	<div class="box1 servicos">
		<h2>Assessment LGPD & Aplicabilidade LGPD</h2>
	</div>

	<div class="box1">
		<p>
			<i class="fas fa-caret-right"></i> Estudo da LGPD e demais leis que regulamentam o seu negócio<br><br>
			<i class="fas fa-caret-right"></i> Mapear a entrada e o tratamento dos dados pessoais<br><br>
			<i class="fas fa-caret-right"></i> Mapear os riscos do tratamento<br><br>
			<i class="fas fa-caret-right"></i> Criar a política de proteção de dados e adaptar os documentos internos e externos<br><br>
			<i class="fas fa-caret-right"></i> Treinamento das equipes que tratam dados pessoais <br><br>
			<i class="fas fa-caret-right"></i> Exigir o compliance da proteção de dados de seus fornecedores<br><br>
			<i class="fas fa-caret-right"></i> Eleger um DPO com conhecimentos regulatórios sobre proteção de dados<br><br>
			<i class="fas fa-caret-right"></i> Elaborar o Relatório de Impacto<br><br>
			<i class="fas fa-caret-right"></i> Gerenciar os pedidos dos titulares e dos órgãos<br><br>
			<i class="fas fa-caret-right"></i> Ser compliance com a proteção de dados mediante governança<br><br>
			<i class="fas fa-caret-right"></i> Concepção de novos produtos com o princípio de Privacy By Design
		</p>
	</div>


	<div class="box1">
		<p>
			Guia de boas práticas LGPD: <a href="https://www.gov.br/governodigital/pt-br/governanca-de-dados/guia-de-boas-praticas-lei-geral-de-protecao-de-dados-lgpd" target="_blank">https://www.gov.br/governodigital/pt-br/governanca-de-dados/guia-de-boas-praticas-lei-geral-de-protecao-de-dados-lgpd</a>
		</p>
	</div>



	<div class="box1 parceiros">
		<h2>PARCERIA INTERNACIONAL</h2>
		<img src="[template]/pw-images/portfolio/bottomline-parceiro.png" alt="Bottomline Parceiro" title="Bottomline Parceiro" />
		<p>SOLUTIONS:</p>
		<p>PAYMODE – X | PAYMENT NETWORK | DIGITAL BANKING | FINANCIAL MESSAGING | LEGAL SPEND MANAGEMENT | CYBER FRAUD AND RISK MANAGEMENT</p>
		<a href="https://www.bottomline.com/US" title="">Site: https://www.bottomline.com/US</a>
	</div>


</div> <!-- Conteudo Pages -->
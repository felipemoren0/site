<?php
	$dadosPagina["titulo"]   = "Suporte e Infraestrutura de TI";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Suporte Técnico Remoto e IN Loco, Suporte Presencial, Suporte Residente, Suporte nas Auditorias de TI.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Suporte e Infraestrutura de TI\" />";
	$dadosPagina["css"] = "";
?>

<h1>SUPORTE INFRAESTRUTURA</h1>

<div class="conteudo-pages">

	<div class="box1">
		<p>Serviços de Infraestrutura</p>

		<p>Alocação de profissionais de diversos níveis: especialistas, consultores, analistas e técnicos. <br><br>

			Suporte a redes e ativos;<br><br>

			Suporte aplicações e serviços de Cloud Microsoft, IBM, Google e AWS;<br><br>

			Monitoramento do Negócio via Zabbix – NOC;<br><br>

			Suporte e alocação de impressoras, computadores e periféricos de informática;<br><br>

			Suporte a servidores Linux e Windows;<br><br>

		</p>
	</div>

	<div class="box1 servicos">
		<h2>Projetos de partideira: </h2>
	</div>

	<div class="box1">
		
		<p><i class="fas fa-caret-right"></i> Instalar, configurar e administrar ativos de TI corporativa;<br><br>
			<i class="fas fa-caret-right"></i> Planejar e executar a evolução tecnológica dos ambientes de TI;<br><br>
			<i class="fas fa-caret-right"></i> Testes com novas tecnologias, novas ferramentas (exemplos: pocket PCs, wireless devices, servidores com particionamento, tablet, PCs);<br><br>
			<i class="fas fa-caret-right"></i> Migração de versões de software básico (sistemas operacionais, bancos de dados, middleware, backup)<br><br>
			<i class="fas fa-caret-right"></i> Migração de plataforma de hardware (novas máquinas, novos equipamentos de storage);<br><br>
			<i class="fas fa-caret-right"></i> Estudo de viabilidade de novas tecnologias;<br><br>
			<i class="fas fa-caret-right"></i> Melhor reutilização de tecnologias e recursos existentes;<br><br>
			<i class="fas fa-caret-right"></i> Configurar e administrar a segurança lógica:<br><br>
			<i class="fas fa-caret-right"></i> Definir políticas e tecnologias para fortalecer a segurança das informações e dos ambientes de TI;<br><br>
			<i class="fas fa-caret-right"></i> Definir e manter regras em firewalls.
		</p>

	</div>



</div> <!-- Conteudo Pages -->

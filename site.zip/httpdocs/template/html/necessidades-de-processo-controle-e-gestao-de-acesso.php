<?php
	$dadosPagina["titulo"]   = "Necessidades de Processo, Controle e Gestão de Acesso";
	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Melhorias na Auditoria Interna e Externa, Definição de Metodologias Aplicadas em TI, Gestão de Configurações, Processo de Mudanças, Procedimentos e Normas de TI.\" />";
	$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Necessidades de Processo, Controle e Gestão de Acesso\" />";
	$dadosPagina["css"] = "";
?>

<h1>Governança de TI</h1>

<div class="conteudo-pages">

	<div class="texto-pages">
		<h2><i class="far fa-lightbulb"></i> Departamento de Governança de TI</h2>
			<p>É parte integral da Governança Corporativa de uma empresa e tem a função de alinhar a estratégia de TI com as estratégias do negócio para assegurar que todos os investimentos de TI sejam adequados para o alcance das metas e objetivos organizacionais e traga retorno ROI, segurança e conformidade com os processos estabelecidos.</p>

			<p>A Governança de TI fornece uma estrutura planejada e diretrizes para a liderança aplicar em todos os níveis do negócio e integrar todas as ferramentas e iniciativas de TI com a estratégia para gerar valor e alcançar metas e objetivos.</p>

			<br>

			<div class="governanca-total">

				<div class="governanca">
					<div class="governanca-titulo">
	        	<h2><i class="fas fa-chevron-circle-right"></i> IT Governance Consultant</h2>
					</div>
					<div class="governanca-desc">
	          <p>O termo é designado à profissionais que são responsáveis por administrar um programa de Governança. Cabe a eles desenvolver e coordenar todas os padrões em processos, procedimentos, normas, matriz de riscos e estratégias que precisam ser tomadas no âmbito organizacional. Os IT Governance Consultant podem atuar internamente ou externamente.</p>
					</div>
				</div>
			</div>

				<br>

        <h2><i class="fas fa-handshake"></i> Veja onde podemos apoiar</h2>
          <p>A ASB Technology obtém os modelos de Governança de TI adequados para alcance dos resultados esperados pela organização, esses modelos se adaptam nas necessidades da organização, efetuando o levantamento dos processos atuais com analise de gaps e indicando as melhores práticas de mercado, visando a representação dos serviços de TI de modo indicativo e sustentável.</p>

					<br>

          <p><b>Macro escopo de ações:</b></p>

            <ul>
              <li>Alinhamento estratégico</li>
              <li>Entrega de valor</li>
              <li>Gestão de risco</li>
              <li>Gestão de recursos</li>
              <li>Mensuração de desempenho</li>
            </ul>

	</div><!-- Texto Pages -->

</div> <!-- Conteudo Pages -->

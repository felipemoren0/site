<?php

	$dadosPagina["titulo"]   = "Projeto Web Site - Agradecemos Seu Contato";

	$dadosPagina["metas"][0] = "<meta name=\"description\" content=\" \" />";

	$dadosPagina["metas"][2] = "<meta name=\"title\" content=\" Projeto Web Site - Agradecemos Seu Contato\" />";
	$dadosPagina["css"]= "<style> .entrar a {font-family: Calibri; width: 560px; display: block; text-align: center; background: #ED7547; color: #fff; font-size: 25px; padding: 20px 0px; border-radius: 20px; box-shadow: 3px 3px 0px 2px #B93F11; margin-bottom: 20px; font-weight: lighter; } .confirma-total { width: 1235px; margin: auto; padding: 100px 0; z-index: 99999; position: relative; display: flex; flex-wrap: wrap; justify-content: space-around; align-items: center; } .frase p {font-family: Calibri; margin: 60px 0; font-size: 35px; font-weight: lighter; } .titulo h1 { font-size: 40px; color: #DC6B3F; font-family: Helvetica; font-weight: lighter; } .conteudo { width: 750px; }
    </style>";

?>


    <div class="confirma-total">

        <div class="imagem">
            <img src="[template]/images/confirma.png" alt="">
        </div>

        <div class="conteudo">
            <div class="titulo">
                <h1>Sua Mensagem foi enviada com sucesso!</h1>
            </div>
            <div class="frase">
                <p>Em breve retornaremos o seu contato.</p>
            </div>
            <div class="entrar">

                <a href="[url]/" title="Agência Digital, Projetos Web, Marketing Digital, Websites e Sites">Continue navegando pelo nosso site</a>

            </div>
        </div>

    </div>

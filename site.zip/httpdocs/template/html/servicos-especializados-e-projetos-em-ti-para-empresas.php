<?php
$dadosPagina["titulo"]   = "Serviços Especializados e Projetos em TI para Empresas";
$dadosPagina["metas"][0] = "<meta name=\"description\" content=\"Segurança da Informação, Modelagem de Processos, Auditoria Interna e Externa, Capacitação ITIL, Otimização de Atividades Empresariais e Entrega de Valor ao Negócio.\" />";
$dadosPagina["metas"][1] = "<meta name=\"title\" content=\"Serviços Especializados e Projetos em TI para Empresas\" />";
$dadosPagina["css"] = "";
?>

<h1>Portfólio</h1>

<div class="conteudo-pages">

	<div class="box1 servicos">
		<h2>GOVERNANÇA | COMPLIANCE | SEGURANÇA DA INFORMAÇÃO | SUPORTE - INFRAESTRUTURA DE TI</h2>
	</div>

	<div class="box1">
		<h2>ASB TECHNOLOGY - OVERVIEW</h2>
		<p>A ASB Technology é uma empresa de TI localizada em São Paulo, somos especializados em serviços de consultoria nas mais diversas áreas de Tecnologia. Nosso objetivo é trazer agilidade nos processos, melhoria dos indicadores, mapeamento e controle de risco.</p>
		<p>Desenvolvemos uma Governança eficiente com base nas melhores praticas de TI, nossa equipe é especializada nos principais frameworks - ISO 2000, ISO 27001, ISO 27002, ITIL, COBIT, atendemos as empresas de todos os portes e segmentos.</p>
		<p>Missão - prover a governança TI de forma estratégica ao negócio, desenvolver serviços e soluções de tecnologia atualizados e inovadores.</p>
		<p>Formação - criada por profissionais que estão no mercado de tecnologia há mais de 10 anos, a ASB Technology tem um modelo de atendimento totalmente personalizado, levando consultores que entendam o dia a dia do negócio e propondo soluções que vão de encontro com as necessidades dos clientes, aumentando assim a eficiência e consequentemente reduzindo custos, pontos de auditoria e retrabalho.</p>
	</div>

	<div class="box1">
		<div class="box2-total">
			<div class="box2">
				<div class="box2-desc">
					<p>A ASB Technology promove a globalização de processos de Governança TI, com mensuração constante da qualidade dos serviços.</p>
				</div>
			</div>
			<div class="box2">
				<div class="box2-desc">
					<img src="[template]/pw-images/portfolio/consultoria-em-tecnologia.jpg" alt="Consultoria em Tecnologia" title="Consultoria em Tecnologia" />
				</div>
			</div>
		</div>
	</div>

	<div class="box1 servicos">
		<h2>NOSSOS SERVIÇOS</h2>
	</div>

	<div class="box1">
		<div class="box2-total">
			<div class="box2">
				<div class="box2-desc">
					<h2>SEGURANÇA DA INFORMAÇÃO</h2>
				</div>
			</div>
			<div class="box2">
				<div class="box2-desc">
					<img src="[template]/pw-images/portfolio/seguranca-da-informacao-em-sp.png" alt="Segurança da Informação em São Paulo" title="Segurança da Informação em São Paulo" />
				</div>
			</div>
		</div>

		<div class="lista">

			<ul>

				<li id="1"><i class="fas fa-caret-right"></i> Analise de Vulnerabilidade (Interna e externa)
					<br>
					<div class="oculta">
						<p>Mapeamento de vulnerabilidades encontradas no ambiente através de uma análise geral (Ativos de Segurança - Firewalls, Switch, Redes, Servidores, estações de trabalho).</p>
						<p>Extração de relatório com apontamento de criticidade por vulnerabilidade identificada. </p>
						<p>Criação de plano de ação com base nos recursos técnicos identificados para solução de longo, médio e curto prazo.</p>
					</div>
				</li>

				<li id="2"><i class="fas fa-caret-right"></i> Análise de riscos ao negócio
					<br>
					<div class="oculta">
						<p>Entender o negócio e aplicar as melhores práticas de segurança nos recursos e processos de TI conforme as necessidades identificadas.</p>
						<p>Blindagem: Mapeamento de risco, definição da matriz de responsabilidade, indicar e/ou implementar ferramenta de segurança, definir processo de resposta à incidentes, avaliar os controles dos sistemas core.</p>
					</div>
				</li>

				<li id="3"><i class="fas fa-caret-right"></i> Pentest
					<br>
					<div class="oculta">
						<p>Teste de Invasão / Intrusão do Ambiente (Infraestrutura): Através desse teste é possível simular os possíveis ataques de cibercriminosos no ambiente de TI, roubo ou perda de dados, impacto na Imagem e integridade da empresa.</p>
						<p>Pentest Black Box: é uma simulação de ataque mais próximo de um ataque externo real, pois nenhuma informação sobre a empresa e informações técnicas são fornecidas a empresa de Pentest. </p>
						<p>Pentest Grey Box: é uma simulação de ataque mais direcionado a um ou mais recursos informados pelo cliente, afim de testar a segurança de um determinado ambiente, neste modelo algumas informações são enviadas a empresa de Pentest. </p>
						<p>Pentest White Box: essa simulação é mais aberta, onde o cliente passa todas as informações necessárias para identificação dos ambientes, com acessos limitados, permitindo a percepção de possíveis fraudes dentro da empresa ou com possíveis risco externo.</p>
					</div>
				</li>

				<li id="4"><i class="fas fa-caret-right"></i> Conscientização das melhores práticas de segurança
					<br>
					<div class="oculta">
						<p>Workshop (dicções sobre segurança da informação e impactos no mercado geral, principais ferramentas, controle e monitoramento). </p>
						<p>Treinamentos (treinamento técnico, treinamento de usuário final, simulações de ataque Phishing)</p>
						<p>Gestão de acesso (organização de acesso adm, segregação de acesso, unificação de acesso, padronização de senha infraestrutura e sistemas).</p>
					</div>
				</li>

				<li id="5"><i class="fas fa-caret-right"></i> Hardening do Ambiente
					<br>
					<div class="oculta">
						<p>Mapeamento de ameaça e riscos identificados na análise de vulnerabilidade</p>
						<p>Mitigação de ameaças e fortalecimento do ambiente.</p>
						<p>Esse escopo prepara o ambiente de TI nas atuais leis e políticas de segurança utilizada no mercado, suporte a empresa na conformidade da baseline de segurança, incluindo um planejamento estratégico para solução definitiva em cada atividade de melhoria identificada.</p>
					</div>
				</li>

				<li id="6"><i class="fas fa-caret-right"></i> Monitoramento SOC – Security Operations Center
					<br>
					<div class="oculta">
						<p>Absorvemos em nossa estrutura o monitoramento de segurança dos ambientes do cliente com registro de alertas e incidentes para ação proativa e preventiva através da ferramenta Splunk. </p>
						<p>Desenhamos processos de segurança de ponta a ponta, afim de preparar os clientes na organização e acionamento dos envolvidos conforme a criticidade do incidente.</p>
						<p>Executamos projeto de implantação de SOC na ferramenta do cliente ou na Splunk nossa ferramenta, após implantação é efetuada a organização dos treinamentos operacional para sustentação da ferramenta de monitoramento.</p>
					</div>
				</li>

				<li id="7"><i class="fas fa-caret-right"></i> Analise de Maturidade do nível de segurança
					<br>
					<div class="oculta">
						<p>É executado um mapeamento geral dos recursos de tecnologia e atuais acessos, controles, processos e monitoramento, afim de analisar o nível de maturidade em relação as melhores práticas de TI. </p>
						<p>Definição de matriz de responsabilidade e risco para aplicação de metas e acompanhamentos das atividades de correção de ambiente.</p>
						<p>Gestão: Visão dos impactos no ambiente de TI e Negócio. </p>
						<p>Acompanhamento da redução /extinção de risco.</p>
					</div>
				</li>

				<li id="8"><i class="fas fa-caret-right"></i> Implantação de certificado digital
					<br>
					<div class="oculta">
						<p>Implantação, configuração e sustentação de Certificados Digitais.</p>
						<p>Além de executarmos as configurações para proteção dos dados na internet, também sustentamos as manutenções e atualizações dos certificados garantindo a aderência do mesmo dentro das boas práticas da ITI - (Instituto Nacional de Tecnologia da Informação).</p>
					</div>
				</li>

				<li id="9"><i class="fas fa-caret-right"></i> Soluções de Antifraude
					<br>
					<div class="oculta">
						<p>Implantação e Suporte de solução antifraude reconhecida pelo mercado (Intellinx)</p>
						<p>Configuração e Desenvolvimento de regras customizadas para o negócio</p>
						<p>Análise e Auditoria de eventos capturados pelo sistema.</p>
					</div>
				</li>

			</ul>
		</div>

	</div>

	<div class="box1">
		<div class="box2-total">
			<div class="box2">
				<div class="box2-desc">
					<h2>GOVERNANÇA E COMPLIANCE</h2>
				</div>
			</div>
			<div class="box2">
				<div class="box2-desc">
					<img src="[template]/pw-images/portfolio/governanca-e-compliance-em-sp.jpg" alt="Governança e Compliance em São Paulo" title="Governança e Compliance em São Paulo" />
				</div>
			</div>
		</div>

		<div class="lista">

			<ul>

				<li id="1"><i class="fas fa-caret-right"></i> Desenvolvimento de processos e matriz RACI
					<br>
					<div class="oculta">
						<p>Mapeamento de processos As Is e desenvolvimento de processos To Be</p>
						<p>Definição de escopo de atividades e restruturação das áreas corporativas.</p>
						<p>Implantação de Processos ITIL, COBIT, ISO 20000, ISO 27001 e ISO 27002, SCRUM, Ciclo de Desenvolvimento.</p>
					</div>
				</li>

				<li id="2"><i class="fas fa-caret-right"></i> Criação do Ciclo de Melhoria Contínua PDCA
					<br>
					<div class="oculta">
						<p>Assessment baseado na análise de pessoas, processos e ferramentas:</p>
						<p>Objetivo de melhorar a usabilidade e o compliance dos processos da TI, a interação e colaboração de pessoas, melhorar o manuseio das ferramentas e aplicativos.</p>
						<p>Desenvolvimento de controles baseados nos frameworks:</p>
						<p>CUP – Controle de Uso do Processo</p>
						<p>CEP - Controle Estatístico do Processo</p>
					</div>
				</li>

				<li id="3"><i class="fas fa-caret-right"></i> Implementação de processos com as melhores práticas ITIL
					<br>
					<div class="oculta">
						<p>Gestão de Incidentes</p>
						<p>Gestão de Problemas</p>
						<p>Gestão de Requisição</p>
						<p>Gestão de Mudança</p>
						<p>Gestão de Fornecedores</p>
						<p>CMDB/BDGC - Banco de Dados do Gerenciamento da Configuração</p>
						<p>Gestão de Contratos</p>
						<p>Gestão de Riscos</p>
						<p>Gestão de Controles Internos</p>
						<p>Automação de Processos BPMN, através de soluções ITSM</p>
					</div>
				</li>

				<li id="4"><i class="fas fa-caret-right"></i> Consultoria de implementação e melhoria de ferramentas ITSM
					<br>
					<div class="oculta">
						<p>Criação de catálogos de serviços</p>
						<p>Controle de SLA e OLA</p>
						<p>Gestão de Licenças</p>
						<p>KPI de alta gestão e operacionais</p>
						<p>Configuração de eventos para workflow</p>
						<p>Notificação automática e escalation</p>
						<p>Implantação de Knowledge</p>
					</div>
				</li>

				<li id="5"><i class="fas fa-caret-right"></i> Treinamento ITIL, COBIT, Boas Práticas de Segurança, Desenvolvimento
					<br>
					<div class="oculta">
						<p>Tecnologia da Informação: ITIL, COBIT, Segurança da Informação, Agile Scrum </p>
						<p>Produtividade e Desempenho: Meetups, Workshop para projetos e operação de processos específicos, alinhamento de metas e objetivos.</p>
					</div>
				</li>

				<li id="6"><i class="fas fa-caret-right"></i> Desenvolvimento de Processos, Procedimentos, Guia e Normas, Controles Internos e Auditoria
					<br>
					<div class="oculta">
						<p>Desenvolvimento de procedimentos, guias e normas para controles internos e auditoria.
						<p>Controle de vigência do Processo (meter atualizado e usual) </p>
						<p>Checklist operacional</p>
						<br>
						<p>Benefícios:</p>
						<br>
						<p>Melhorias das atividades rotineiras</p>
						<p>Escopo de trabalho definido</p>
						<p>Indicadores baseados em objetivos para alcance das metas da organização</p>
						<p>Processos controlados e com selo de vigência</p>
						<p>Rotina de avaliação de maturidade do processo e atividades.</p>
						<p>Baseline de segurança aplicada e controlada</p>
						<p>Avalição dos fornecedores em tempo de resposta e SLA</p>
						<p>Entrega de processos mapeados de acordo com os requisitos das auditorias - interna e externas PWC|EY|DELOITTE.</p>
					</div>
				</li>

			</ul>
		</div>
	</div>

	<div class="box1 parceiros">
		<h2>PARCERIA INTERNACIONAL</h2>
		<img src="[template]/pw-images/portfolio/bottomline-parceiro.png" alt="Bottomline Parceiro" title="Bottomline Parceiro" />
		<p>SOLUTIONS:</p>
		<p>PAYMODE – X | PAYMENT NETWORK | DIGITAL BANKING | FINANCIAL MESSAGING | LEGAL SPEND MANAGEMENT | CYBER FRAUD AND RISK MANAGEMENT</p>
		<a href="https://www.bottomline.com/US" title="">Site: https://www.bottomline.com/US</a>
	</div>


</div> <!-- Conteudo Pages -->
<meta http-equiv="refresh" content="5; url=[url]"  />

<?php
	$dadosPagina["titulo"] = "Página Interna";
?>

<div class="conteudo-pages page-404">

	<div id="imagem-centralizada"><img src="[template]/pw-images/pagina-nao-encontrada.jpg"/></div>

	
</div> <!-- Conteudo Pages -->


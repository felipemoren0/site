jQuery(function(){
	jQuery('.menu-resp').click(function(e) {
		jQuery(this).next().slideToggle(300);
	});
});

jQuery(function () {
	var href = $('.menu a').attr('href');
    var res = href.replace(/:443/g, "");
    var currentUrl = $(location).attr('href');

    if(res == currentUrl){
        $('a[href*="'+href+'"]').addClass("ativo");
    }
});

jQuery(document).ready(function() {

	jQuery('.mapa iframe').css('pointer-events','none');
	jQuery('.mapa').click(function(){
	jQuery('.mapa iframe').css('pointer-events','auto');
	});
	jQuery('.mapa').mouseleave(function(){
	jQuery('.mapa iframe').css('pointer-events','none');
	});
});

jQuery(document).ready(function() {
	jQuery('.galeria a').attr('data-fancybox','galeria');

				$('[data-fancybox="galeria"]').fancybox({
						arrows: true,
						buttons: [
								"zoom",
								"thumbs",
								"close"
						],
						animationEffect: "fade",
						transitionEffect: "fade",
						loop: true,
						gutter: 50,
						keyboard: true,
						arrows: true,
				});

				var swiper = new Swiper('.swiper-container', {
			    pagination: '.swiper-pagination',
			    slidesPerView: 1,
			    loop: true,
			    slidesPerColumn: 1,
			    paginationClickable: true,
			    spaceBetween: 0,
			    nextButton: '.swiper-button-next',
			    prevButton: '.swiper-button-prev',
			    freeMode: false
			  });
				var swiper = new Swiper('.swiper-container-02', {
			    pagination: '.swiper-pagination',
			    slidesPerView: 1,
			    loop: true,
			    slidesPerColumn: 1,
				autoplay: 4000,
				effect: 'fade',
			    paginationClickable: true,
			    spaceBetween: 0,
			    nextButton: '.swiper-button-next',
			    prevButton: '.swiper-button-prev',
			    freeMode: false
			  });

});

jQuery('img.bgParallax').each(function(){
	var $obj=jQuery(this);
	jQuery(window).scroll(function(){
		var yPos=-(jQuery(window).scrollTop()/$obj.data('speed'));
		var bgpos=yPos+'px';$obj.css('margin-top',bgpos);
	});
});

jQuery('.lista li').on('click', function () {
    $parent_box = jQuery(this);
    $parent_box.siblings().find('.oculta').slideUp();
    $parent_box.find('.oculta').slideToggle();
});

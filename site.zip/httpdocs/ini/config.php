<?php

    /* Configurações personalizaveis
        - Diretorio de Includes
        - Diretorio de Classes dentro do diretorio de Includes
        - Diretorio de JS
        - Diretorio de Paginas
        - Diretorio de Template
    */
    
    $js       = "pw-js";
    $paginas  = "template/html";
    $template = "template";
    
?>